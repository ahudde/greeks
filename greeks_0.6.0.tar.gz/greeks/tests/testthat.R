library(testthat)
library(greeks)

test_check("greeks")
