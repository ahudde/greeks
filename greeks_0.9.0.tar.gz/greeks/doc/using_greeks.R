### This is an R script tangled from 'using_greeks.pdf.asis'
