## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib greeks, .registration = TRUE
## usethis namespace: end
